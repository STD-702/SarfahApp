package com.example.sarfahapp

data class Delegate(
    val delegateId: Int,
    val name: String,
    val relation: String
)