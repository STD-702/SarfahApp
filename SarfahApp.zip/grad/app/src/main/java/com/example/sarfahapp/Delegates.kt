package com.example.sarfahapp

data class Delegates(
    val delegateId: Int,
    val name: String,
    val relation: String
)