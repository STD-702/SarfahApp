package com.example.sarfahapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AddStudentsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_students)
    }
}